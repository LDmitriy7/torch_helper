from torchvision.transforms import transforms
from torchvision.datasets.mnist import MNIST
from .data_loader import create_data_loaders

DATA_PATH = "data"

mnist_transform = transforms.ToTensor()


def load_mnist_train_dataset(path: str = DATA_PATH):
    dataset = MNIST(path, download=True)
    dataset.transform = mnist_transform
    return dataset


def load_mnist_test_dataset(path: str = DATA_PATH):
    dataset = MNIST(path, train=False, download=True)
    dataset.transform = mnist_transform
    return dataset


def load_mnist_datasets():
    train_dataset = load_mnist_train_dataset()
    test_dataset = load_mnist_test_dataset()
    return train_dataset, test_dataset


def create_mnist_data_loaders():
    train_dataset, test_dataset = load_mnist_datasets()
    return create_data_loaders(train_dataset, test_dataset)
