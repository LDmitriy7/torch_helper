from typing import Iterator
from torch import Tensor
from torch.utils import data

BATCH_SIZE = 64
NUM_WORKERS = 6
DEVICE = "cuda"


class DataLoader(data.DataLoader):
    def __init__(
        self,
        dataset: data.Dataset,
        batch_size: int = BATCH_SIZE,
        shuffle: bool = False,
        num_workers: int = NUM_WORKERS,
    ):
        super().__init__(
            dataset,
            batch_size,
            shuffle=shuffle,
            num_workers=num_workers,
            persistent_workers=True,
            pin_memory=True,
        )

    def __iter__(self) -> Iterator[tuple[Tensor, Tensor]]:
        return super().__iter__()


def iter_batches(data_loader: DataLoader):
    for batch in data_loader:
        x, y = [i.to(DEVICE) for i in batch]
        yield x, y


def create_data_loaders(train_dataset: data.Dataset, test_dataset: data.Dataset):
    train_data_loader = DataLoader(train_dataset, shuffle=True)
    test_data_loader = DataLoader(test_dataset)
    return train_data_loader, test_data_loader
