from torch import nn, Tensor


class Model(nn.Module):
    def forward(self, x: Tensor) -> Tensor:
        return x

    def __call__(self, x: Tensor) -> Tensor:
        return super().__call__(x)


class SeqModel(Model):
    def __init__(self, seq: nn.Sequential):
        super().__init__()
        self.seq = seq

    def forward(self, x: Tensor) -> Tensor:
        return self.seq(x)
