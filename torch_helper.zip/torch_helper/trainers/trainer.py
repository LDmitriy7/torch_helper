from torch import nn, Tensor, optim
import torch
from torch_helper.data_loader import DataLoader, DEVICE, iter_batches
from .loss import LossFn


class Trainer:
    def __init__(
        self,
        model: nn.Module,
        loss_fn: LossFn,
    ):
        self._model = model.to(DEVICE)
        self._loss_fn = loss_fn
        self.optimizer = optim.AdamW(model.parameters())
        self.load()

    def fit(
        self,
        train_data_loader: DataLoader,
        test_data_loader: DataLoader,
        epochs_count: int = 10,
    ):
        best_loss = self._calc_test_loss(test_data_loader)
        for _ in range(epochs_count):
            loss = self._fit_step(train_data_loader, test_data_loader)
            if loss < best_loss:
                best_loss = loss
                self.save()
            self._log_loss(loss, best_loss)

    def save(self):
        pass

    def load(self):
        pass

    def _fit_step(
        self,
        train_data_loader: DataLoader,
        test_data_loader: DataLoader,
    ) -> float:
        loss = self._train_epoch(train_data_loader)
        print(f"Train loss: {loss:.5f}")
        loss = self._calc_test_loss(test_data_loader)
        return loss

    def _calc_test_loss(self, data_loader: DataLoader) -> float:
        self._model.eval()
        cum_loss = 0
        batch_count = len(data_loader)

        with torch.no_grad():
            for x, y in iter_batches(data_loader):
                loss = self._calc_loss(x, y)
                cum_loss += loss.item()

        return cum_loss / batch_count

    def _calc_loss(self, x: Tensor, y: Tensor) -> Tensor:
        pred_y = self._model(x)
        return self._loss_fn(pred_y, y)

    def _train_epoch(self, data_loader: DataLoader) -> float:
        self._model.train()
        cum_loss = 0
        batch_count = len(data_loader)

        for x, y in iter_batches(data_loader):
            loss = self._train_step(x, y)
            cum_loss += loss.item()

        return cum_loss / batch_count

    def _train_step(self, x: Tensor, y: Tensor):
        self.optimizer.zero_grad()
        loss = self._calc_loss(x, y)
        loss.backward()
        self.optimizer.step()
        return loss

    def _log_loss(self, loss: float, best_loss: float):
        print(f"Test loss: {loss:.5f} (Best Loss: {best_loss:.5f})")


# TODO: repr loss func
