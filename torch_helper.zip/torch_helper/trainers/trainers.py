from torch import Tensor, nn
import torch

from .trainer import Trainer, iter_batches
from .loss import calc_cross_entropy_loss, calc_mse_loss
from torch_helper.data_loader import DataLoader


class ClassifierTrainer(Trainer):
    def __init__(self, model: nn.Module):
        super().__init__(model, calc_cross_entropy_loss)

    def calc_accuracy(self, data_loader: DataLoader) -> float:
        self._model.eval()
        total_preds = 0
        correct_preds = 0

        with torch.no_grad():
            for x, y in iter_batches(data_loader):
                pred_y = self._model(x)
                correct_preds += self._calc_correct_preds(pred_y, y)
                total_preds += len(x)

        return correct_preds / total_preds

    def _calc_correct_preds(self, preds: Tensor, targets: Tensor) -> int:
        preds = preds.max(dim=1)[1]
        return (preds == targets).sum().item()


class RegressorTrainer(Trainer):
    def __init__(self, model: nn.Module):
        super().__init__(model, calc_mse_loss)
