from torch import nn

from .trainer import Trainer
from .loss import calc_cross_entropy_loss, calc_mse_loss


class ClassifierTrainer(Trainer):
    def __init__(self, model: nn.Module):
        super().__init__(model, calc_cross_entropy_loss)


class RegressorTrainer(Trainer):
    def __init__(self, model: nn.Module):
        super().__init__(model, calc_mse_loss)
