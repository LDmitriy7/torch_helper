from typing import Callable

from torch import Tensor
from torch.functional import F

LossFn = Callable[[Tensor, Tensor], Tensor]


def calc_cross_entropy_loss(logits: Tensor, target: Tensor) -> Tensor:
    return F.cross_entropy(logits, target)


def calc_mse_loss(pred: Tensor, target: Tensor) -> Tensor:
    return F.mse_loss(pred, target)
